*** Settings ***
Library    SeleniumLibrary
Library    Collections
Library    PlotlyParquetLibrary.py
Suite Teardown    Close All Browsers

*** Variables ***
${REPORT}     ${CURDIR}${/}report.html
${DATASET}    ${CURDIR}${/}facility_type_avg_time_spent_per_visit_date

*** Test Cases ***
Plotly Report Matches Parquet Dataset
    ${url}=    Evaluate    pathlib.Path(r'''${REPORT}''').resolve().as_uri()    modules=pathlib
    Open Browser    ${url}    Chrome
    Wait Until Page Contains Element    css:.js-plotly-plot    timeout=20s
    Wait Until Keyword Succeeds    10x    1s    Plotly Table Should Be Ready
    ${data}=    Execute Javascript
    ...    const graph = document.querySelector('.js-plotly-plot');
    ...    const table = graph?.data?.find(trace => trace.type === 'table');
    ...    if (!table) throw new Error('Plotly table trace not found');
    ...    const headers = table.header.values.map(String);
    ...    const columns = table.cells.values;
    ...    if (columns.length !== headers.length) throw new Error('Column count mismatch');
    ...    const rows = columns.length ? Array.from({length: columns[0].length}, (_, i) => columns.map(c => c[i])) : [];
    ...    return {headers: headers, rows: rows};
    Compare Plotly Data To Parquet    ${data}[headers]    ${data}[rows]    ${DATASET}

*** Keywords ***
Plotly Table Should Be Ready
    ${ready}=    Execute Javascript    return !!document.querySelector('.js-plotly-plot')?.data?.some(t => t.type === 'table')
    Should Be True    ${ready}
